## V1.1.1
- New mod icon
- Minor README changes

## V1.1
- Fixed formatting issues

Added Song
- Whats_New_Scooby_Doo__-_Intro_1080p_16_9.mp3

## V1
Song List
- Aaron_Smith_-_Dancin_KRONO_Remix.mp3
- BRAINDANCE.mp3
- Black_Coast_-_TRNDSTTR_Lucian_Remix.mp3
- Bonnie Tyler - Turn Around (Total Eclipse Of The Heart Official Audio).mp3
- Call_Me_Karizma_-_Rebels_Lyrics.mp3
- Carlie Hanson - 608 (Official Music Video).mp3
- Ghostface Playa - Why Not.mp3
- HOSPICEMANE - RAGE.mp3
- KORDHELL - A MILLION WAYS TO MURDER.mp3
- Mozart_-_Lacrimosa.mp3
- Push Up (Main Edit).mp3
- Sickmode & Rooler - DOWN DOWN (Official Visualizer).mp3
- Sonny Wern, Lyente, Quinten Circle, ZANA - Dance For Me (1, 2, 3) - Stutter Techno.mp3
- Sub Zero Project & Rebelion - Live Fast Die Young (Official Video).mp3
- TAKA TAKA.mp3
- TNT - Boom Boom Boom (Official Hardstyle Video).mp3
- Technikore - DMT [OneSeventy].mp3
- The Isley Brothers - Shout.mp3